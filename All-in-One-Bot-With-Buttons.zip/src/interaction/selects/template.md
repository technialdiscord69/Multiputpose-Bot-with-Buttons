```js
module.exports = {
    name: "select_event_name",
    async execute(client, interaction) {
        //What to do.
    },
};
```